(function($){
$(document).ready(function() { 

	
  $('.gallery-link').magnificPopup({
	  
	   
	  type:'image',
	  gallery:{enabled:true},
	  
				
	  });
	  
	});
	
})( jQuery );  
